<?php
    return [
        'guards'=> [
            'admin' => 'admin',
            'writer' => 'writer'
        ]

    ];
